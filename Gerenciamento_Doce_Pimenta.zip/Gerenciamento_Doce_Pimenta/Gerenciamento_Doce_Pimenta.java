public class Main {
    public static void main(String[] args) {
        Produto produto = new Produto("Teclado Gamer", 10, 199.90);
        ProdutoDAO dao = new ProdutoDAO();
        dao.cadastrarProduto(produto);
    }
}
