@WebServlet("/cadastrar-produto")
public class CadastrarProdutoServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String codigo = request.getParameter("codigo");
        String nome = request.getParameter("nome");
        String fornecedor = request.getParameter("fornecedor");
        int quantidade = Integer.parseInt(request.getParameter("quantidade"));
        double preco = Double.parseDouble(request.getParameter("preco"));

        Produto produto = new Produto(codigo, nome, fornecedor, quantidade, preco);
        ProdutoDAO dao = new ProdutoDAO();
        dao.adicionarProduto(produto);

        response.sendRedirect("sucesso.html");
    }
}
